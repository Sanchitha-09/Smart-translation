package com.example.aryan.handclientside;

public class EndPoints {
    //private static final String ROOT_URL = "http://206.189.132.41/";

    String url="http://192.168.29.177:5000/";

   private static final String ROOT_URL = "http://192.168.29.177:5000/";

    public static final String UPLOAD_URL = ROOT_URL + "upload";
    public static final String UPLOAD_URL_NUMBER = ROOT_URL + "upload";
    public static final String GET_PICS_URL = ROOT_URL + "upload";


}
